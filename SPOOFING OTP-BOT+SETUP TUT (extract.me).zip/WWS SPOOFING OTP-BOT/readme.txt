JOIN https://t.me/+BaajOtmBRpxlZDA0 for More Private Tools and Methods Like This For Free

================================================================================

Thanks for buying our otpbot sourcecode!

STEPS IN SETTINGS UP BOT:-
1.Create Account on github and Heroku
2.Download Github desktop and connect with your account
3.Move the files to github folder in documents (Refer Youtube for help)
then, 
4.Upload the code to github make sure you edited the following on your code..
 
5.In goland-otpbot-api/api.go,file in line 13 and 14 Change Host url and Bot Token

6.In The Same File open go.mod at line 1 and Change github.com/USERNAME/goland-otpbot-api

"USERNAME with your github username and the repo name"

work done now connect your heroku account with github and done your website is active. click on view option it redirect you to website url that is your NGROK URL

7.Follow The Same for goland-otpbot

Change the vars BOT_TOKEN get from https://t.me/BotFather

PLIVO_AUTH_ID & PLIVO_AUTH_TOKEN from plivo.com

OWNER_CHAT_ID -> Chat id
start https://t.me/chat_id_echo_bot for id

Make changes in Go.mod line 1
where USERNAME -> your github username 


and finally done if you need help use support option

================================================================================

JOIN  https://t.me/+BaajOtmBRpxlZDA0 for More Private Tools and Methods Like This For Free